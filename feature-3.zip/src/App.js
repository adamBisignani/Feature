import {
  html,
  render,
  useEffect,
  useState
} from "https://unpkg.com/htm/preact/standalone.module.js";
import { SearchBar } from "./Components/MainModule/SearchBar.js";
import { ContactUs } from "./Components/MainModule/ContactUs.js";
import { SignUp } from "./Components/MainModule/SignUp.js";
import { Products } from "./Components/MainModule/Products.js";
import { getProducts } from "./Services/ProductData.js";

const App = () => {
  // set init state of products to empty array, to be updated with useEffect
  const [products, setProducts] = useState([]);

  useEffect(() => {
    return getProducts().then((products) => {
      setProducts(products);
    });
  }, []); // removed products from dependency array to stop glitching/updates to console

  return html`
  <${SearchBar}></${SearchBar}>
  <${Products} />
  <${ContactUs}></${ContactUs}>
  <${SignUp}></${SignUp}>

  <ul>
  <!-- Later we will add styling to make everything look much more like a shop -->
  <!-- We also will move this HTML mapping for the products module into Products.js -->
    ${products.map(
      (product) => html`<li key="${products}" class="test">
        ${product.id} | ${product.cost} |
        <img src="${product.image}" />
      </li>`
    )}
    </ul>
  `;
};

// render react element into DOM
render(html` <${App} /> `, document.getElementById("app"));
