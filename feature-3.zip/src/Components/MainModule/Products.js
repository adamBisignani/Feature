import { html } from "https://unpkg.com/htm/preact/standalone.module.js";

export function Products({ product }) {
  // this will later include the products list, rendered for the DOM
  return html`<p>Within Products Component</p>`;
}
