import { html } from "https://unpkg.com/htm/preact/standalone.module.js";

//Child component that returns html for the search bar found at the top of the screen
export function SearchBar() {
  return html`
    <p>
      <label for="Main Search"></label>
      <input
        type="text"
        placeholder="Search for cool prints here!"
        name="Search Bar"
        id="SB"
        required
      />
      <button type="submit">Search</button>
    </p>
  `;
}
