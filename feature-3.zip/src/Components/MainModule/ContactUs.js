import { html } from "https://unpkg.com/htm/preact/standalone.module.js";

export function ContactUs() {
  return html`
    <h4>We are here to help! Please reach out to us using any method.</h4>
    <p>Hours are 9-5 EST Monday - Friday</p>
    <p>Phone: 724-757-2872</p>
    <p>Email: printtoday@gmail.com</p>
  `;
}
