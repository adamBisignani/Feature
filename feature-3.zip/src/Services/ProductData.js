// products data service w/ a single method
// requests array of products from Products.json via axios

export function getProducts() {
  const axios = window.axios;
  return axios
    .get(`../../Products.json`) // get json data
    .then((response) => {
      console.log(response.data);
      return response.data.data; // array: data element in Product.json
    })
    .catch((err) => {
      console.log("GET Error: ", err);
    });
}
