# Feature 3 - Preact

Adam Bisignani
Ryan Pairitz

Our feature 3 has several components and uses axios to display our JSON data. We will implement styling in the coming weeks and the JSON file will grow as time goes on. Also, our terms and Conditions are still being reviewed by our legal team and will be posted as soon as we have approval... - Adam (Funny guy - Ryan)

A few preact elements in our feature include parent child components. App.js is our parent and the searchbar, contactus, signup, and products are all children components. ProductData.js serves as our equivalent of users.js from Lecture 8 to use axios to return JSON data to App.js. In the future, we would like this data to be passed to Products.js so the HTML code is not cluttering App.js.

The code cannot be run from a local filesystem due to local browser CORS policies. For proper rendering:

1. Go to the project directory in Terminal.
2. Run python -m http.server (with python3).
3. Visit http://localhost:8000/index.html.
